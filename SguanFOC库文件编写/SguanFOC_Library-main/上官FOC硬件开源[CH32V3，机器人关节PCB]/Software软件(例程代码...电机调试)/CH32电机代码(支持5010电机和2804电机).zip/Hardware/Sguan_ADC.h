/********************************** (C) COPYRIGHT *******************************
 * File Name          : Sguan_ADC.h
 * Author             : Sguan
 * Version            : V1.0.0
 * Date               : 2026-03-15
 * Description        : ADC configuration for CH32V203
 ********************************************************************************/
#ifndef __SGUAN_ADC_H
#define __SGUAN_ADC_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ch32v30x.h"

/* ADCͨ������ */
#define ADC_INJ_CHANNEL_0      ADC_Channel_8   /* PB0 - ADC_IN8 */
#define ADC_INJ_CHANNEL_1      ADC_Channel_9   /* PB1 - ADC_IN9 */

/* ADCע����ͨ���� */
#define ADC_INJ_NUM_OF_CHANNELS 2

/* ADCУ׼ֵ */
extern int16_t Sguan_AdcCalibrationValue;

/* ADC����ֵ�洢 */
extern volatile uint16_t Sguan_AdcInjectedValues[ADC_INJ_NUM_OF_CHANNELS];
extern volatile uint8_t Sguan_AdcConversionComplete;

/* ADC��ʼ������ */
void Sguan_ADC_Init(void);

/* ��ȡADCУ׼ֵ */
int16_t Sguan_GetAdcCalibration(void);

/* ��ȡADCע��ͨ��ת��ֵ */
uint16_t Sguan_GetInjectedValue(uint8_t channel);

/* ���ADCת���Ƿ���� */
uint8_t Sguan_IsAdcConversionComplete(void);

/* ���ADCת����ɱ�־ */
void Sguan_ClearAdcConversionFlag(void);

#ifdef __cplusplus
}
#endif

#endif /* __SGUAN_ADC_H */
