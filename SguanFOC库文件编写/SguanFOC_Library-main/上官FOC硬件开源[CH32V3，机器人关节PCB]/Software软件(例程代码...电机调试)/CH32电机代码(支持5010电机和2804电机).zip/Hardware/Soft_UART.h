#ifndef __SOFT_UART_H
#define __SOFT_UART_H

#include <stdint.h>
#include "debug.h"

void Soft_UART_Init(void);
void Soft_UART_Loop(void);
void Soft_UART_Transmit_IT(const uint8_t *pData, uint16_t Size);


#endif // SOFT_UART_H
