#ifndef __SGUAN_GPIO_H
#define __SGUAN_GPIO_H

#include "debug.h"

void Sguan_GPIO_Init(void);


#endif // SGUAN_GPIO_H
