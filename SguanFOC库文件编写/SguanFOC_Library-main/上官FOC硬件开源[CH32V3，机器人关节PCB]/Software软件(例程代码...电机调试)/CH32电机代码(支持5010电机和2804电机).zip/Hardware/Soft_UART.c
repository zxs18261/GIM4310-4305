#include "Soft_UART.h"

// 内部状态定义
typedef enum {
    UART_STATE_IDLE = 0,    // 空闲状态
    UART_STATE_START,       // 发送起始位 (0)
    UART_STATE_DATA,        // 发送数据位 (8位)
    UART_STATE_STOP         // 发送停止位 (1)
} Soft_UART_State_t;

// 软件串口控制结构体
typedef struct {
    const uint8_t *pTxBuf;      // 发送缓冲区指针
    uint16_t TxSize;            // 待发送总长度
    uint16_t TxCount;           // 当前发送字节索引
    uint8_t  BitIndex;          // 当前字节的位索引 (0-7)
    Soft_UART_State_t State;    // 状态机状态
    volatile uint8_t IsBusy;    // 忙标志位 (1: 正在发送, 0: 空闲)
} Soft_UART_Control_t;

// 局部变量：存放处理数据
static Soft_UART_Control_t g_soft_uart;
#define UART_GPIO_Port  GPIOB
#define UART_Pin        GPIO_Pin_8

// --- 硬件抽象接口 (由用户在外部实现) ---
// 提示：这两个函数建议在头文件中定义为 inline 或由宏实现以减少调用开销
static void Soft_UART_High(void);
static void Soft_UART_Low(void);

// (我自己写)
static void Soft_UART_High(void){
    // 这里我自己填写对应软件串口发送的GPIO引脚
    // HAL_GPIO_WritePin(UART_GPIO_Port,UART_Pin,GPIO_PIN_SET);
    GPIO_SetBits(UART_GPIO_Port,UART_Pin);
}

// (我自己写)
static void Soft_UART_Low(void){
    // 这里我自己填写对应软件串口发送的GPIO引脚
    // HAL_GPIO_WritePin(UART_GPIO_Port,UART_Pin,GPIO_PIN_RESET);
    GPIO_ResetBits(UART_GPIO_Port,UART_Pin);
}

/**
 * @brief 内部处理程序：更新 IO 电平
 * 逻辑：起始位(低), 数据位(LSB), 停止位(高)
 */
static void Soft_UART_Tick(void) {
    if (!g_soft_uart.IsBusy) return;

    switch (g_soft_uart.State) {
        case UART_STATE_START:
            Soft_UART_Low(); // 起始位：拉低
            g_soft_uart.BitIndex = 0;
            g_soft_uart.State = UART_STATE_DATA;
            break;

        case UART_STATE_DATA:
            // 发送当前字节的对应位 (LSB优先)
            if ((g_soft_uart.pTxBuf[g_soft_uart.TxCount] >> g_soft_uart.BitIndex) & 0x01) {
                Soft_UART_High();
            } else {
                Soft_UART_Low();
            }
            
            g_soft_uart.BitIndex++;
            if (g_soft_uart.BitIndex >= 8) {
                g_soft_uart.State = UART_STATE_STOP;
            }
            break;

        case UART_STATE_STOP:
            Soft_UART_High(); // 停止位：拉高
            
            g_soft_uart.TxCount++;
            if (g_soft_uart.TxCount < g_soft_uart.TxSize) {
                // 还有下一个字节，准备发送下一个起始位
                g_soft_uart.State = UART_STATE_START;
            } else {
                // 所有数据发送完毕
                g_soft_uart.IsBusy = 0;
                g_soft_uart.State = UART_STATE_IDLE;
            }
            break;

        default:
            g_soft_uart.IsBusy = 0;
            Soft_UART_High();
            break;
    }
}

/**
 * @brief 初始化软件串口
 */
void Soft_UART_Init(void) {
    g_soft_uart.IsBusy = 0;
    g_soft_uart.State = UART_STATE_IDLE;
    g_soft_uart.pTxBuf = 0;
    g_soft_uart.TxSize = 0;
    g_soft_uart.TxCount = 0;

    // 串口空闲状态应为高电平
    Soft_UART_High();
}

/**
 * @brief 软件串口位时间驱动，在 1MHz 定时器中断中调用
 */
void Soft_UART_Loop(void) {
    Soft_UART_Tick();
}

/**
 * @brief 启动软件串口中断发送 (非阻塞)
 * @param pData 数据首地址
 * @param Size  数据长度
 */
void Soft_UART_Transmit_IT(const uint8_t *pData, uint16_t Size) {
    // 如果正在发送，则忽略此次请求 (或根据需要实现简单的环形队列)
    if (g_soft_uart.IsBusy || Size == 0) return;

    g_soft_uart.pTxBuf = pData;
    g_soft_uart.TxSize = Size;
    g_soft_uart.TxCount = 0;
    g_soft_uart.IsBusy = 1;
    g_soft_uart.State = UART_STATE_START;
}

