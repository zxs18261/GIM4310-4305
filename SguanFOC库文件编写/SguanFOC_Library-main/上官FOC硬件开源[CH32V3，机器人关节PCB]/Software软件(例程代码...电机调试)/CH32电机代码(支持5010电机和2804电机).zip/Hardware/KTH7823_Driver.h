#ifndef __KTH7823_DRIVER_H
#define __KTH7823_DRIVER_H

#include "ch32v30x.h"
#include <stdint.h>

// �Ƕ���غ�
#define KTH7823_ANGLE_MAX     65535.0f
#define KTH7823_2PI           6.283185307f

// ��������
void KTH7823_SPI_Init(void);
uint16_t KTH7823_ReadRawAngle(void);
float KTH7823_ReadAngleRad(void);

#endif
