/********************************** (C) COPYRIGHT *******************************
* File Name          : Sguan_UART.c
* Author             : Sguan
* Version            : V1.0.0
* Date               : 2026/04/19
* Description        : UART driver source file (UART6_TX + USART1_RX)
********************************************************************************/
#include "Sguan_UART.h"
#include "SguanFOC.h"
#include <string.h>

volatile uint8_t rx_data_byte = 0;   // 最近接收到的单个字节
volatile uint8_t rx_data_flag = 0;   // 收到字节标志（1=有新数据）
volatile uint8_t uart_data_received = 0;

/* 私有变量 */
static volatile uint16_t RxCount = 0;


/*********************************************************************
 * @fn      Sguan_UART_Init
 *
 * @brief   初始化UART6_TX (PB8) 和 USART1_RX (PB7)
 *          波特率1M，8位数据，1位停止位，无校验
 *          
 *          UART6_TX: PB8 (重映射 USART6_TX_1)
 *          USART1_RX: PB7 (重映射 USART1_RX_1)
 *
 * @return  none
 *********************************************************************/
void Sguan_UART_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};
    
    /* 使能时钟 */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    /* 重映射USART1_RX到PB7 */
    GPIO_PinRemapConfig(GPIO_Remap_USART1, ENABLE);
    
    /* 配置PB7为浮空输入 */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    /* 重新初始化USART1结构体 */
    // USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_BaudRate = 40000;
    // USART_InitStructure.USART_BaudRate = 30000;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx;  // 只接收
    USART_Init(USART1, &USART_InitStructure);
    
    /* 配置接收完成中断 (RXNE) */
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    
    /* 配置NVIC中断优先级 */
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* 使能USART1 */
    USART_Cmd(USART1, ENABLE);
}


/*********************************************************************
 * @fn      Sguan_UART_GetRxBuffer
 *
 * @brief   获取接收缓冲区指针
 *
 * @return  接收缓冲区指针
 *********************************************************************/
uint8_t* Sguan_UART_GetRxBuffer(void)
{
    return Sguan_PrintfBuff;
}

/*********************************************************************
 * @fn      Sguan_UART_GetRxCount
 *
 * @brief   获取已接收数据长度
 *
 * @return  已接收数据长度
 *********************************************************************/
uint16_t Sguan_UART_GetRxCount(void)
{
    return RxCount;
}

/*********************************************************************
 * @fn      Sguan_UART_ClearRxCount
 *
 * @brief   清除接收计数
 *
 * @return  none
 *********************************************************************/
void Sguan_UART_ClearRxCount(void)
{
    RxCount = 0;
}

/*********************************************************************
 * @fn      USART1_IRQHandler
 *
 * @brief   USART1中断处理函数（接收中断）
 *          接收数据并存入缓冲区，当收到'?'时调用解析函数
 *
 * @return  none
 *********************************************************************/
void USART1_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void USART1_IRQHandler(void)
{
    uint8_t data;
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        data = USART_ReceiveData(USART1);
        uart_data_received = 1;   // 只要收到数据，立即置位标志

        if(RxCount < 200 - 1)
        {
            Sguan_PrintfBuff[RxCount++] = data;
            
            if(data == '?')
            {
                SguanFOC_Printf_Loop(Sguan_PrintfBuff, RxCount);
                RxCount = 0;
            }
        }
        else
        {
            RxCount = 0;
        }
    }
}

