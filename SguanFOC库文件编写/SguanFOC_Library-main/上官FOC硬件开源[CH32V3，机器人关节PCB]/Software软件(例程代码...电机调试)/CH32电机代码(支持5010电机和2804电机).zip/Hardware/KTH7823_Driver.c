#include "KTH7823_Driver.h"

// KTH7823 SPI ���Ŷ��壨�����ṩ��Sguan_SPIһ�£�
#define KTH7823_SPI          SPI1
#define KTH7823_CS_PIN       GPIO_Pin_3
#define KTH7823_CS_PORT      GPIOA
#define KTH7823_SCK_PIN      GPIO_Pin_5
#define KTH7823_MOSI_PIN     GPIO_Pin_7
#define KTH7823_MISO_PIN     GPIO_Pin_6

// CS����
#define KTH7823_CS_LOW()     GPIO_ResetBits(KTH7823_CS_PORT, KTH7823_CS_PIN)
#define KTH7823_CS_HIGH()    GPIO_SetBits(KTH7823_CS_PORT, KTH7823_CS_PIN)

/**
 * @brief  KTH7823 SPI ��ʼ������ͨ����ģʽ��Mode3: CPOL=1, CPHA=1��
 */
void KTH7823_SPI_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    SPI_InitTypeDef  SPI_InitStructure;

    // ��ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_SPI1, ENABLE);

    // CS �������
    GPIO_InitStructure.GPIO_Pin   = KTH7823_CS_PIN;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(KTH7823_CS_PORT, &GPIO_InitStructure);
    KTH7823_CS_HIGH();

    // SCK MOSI ��������
    GPIO_InitStructure.GPIO_Pin = KTH7823_SCK_PIN | KTH7823_MOSI_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // MISO ��������
    GPIO_InitStructure.GPIO_Pin = KTH7823_MISO_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // SPI ���� Mode3
    SPI_InitStructure.SPI_Direction         = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode              = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize          = SPI_DataSize_16b;
    SPI_InitStructure.SPI_CPOL              = SPI_CPOL_High;
    SPI_InitStructure.SPI_CPHA              = SPI_CPHA_2Edge;
    SPI_InitStructure.SPI_NSS               = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;
    SPI_InitStructure.SPI_FirstBit         = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial     = 7;

    SPI_Init(KTH7823_SPI, &SPI_InitStructure);
    SPI_Cmd(KTH7823_SPI, ENABLE);
}

/**
 * @brief  SPI ��д16λ���ݣ�������
 */
static uint16_t KTH7823_SPI_ReadWrite16(uint16_t data)
{
    while (SPI_I2S_GetFlagStatus(KTH7823_SPI, SPI_I2S_FLAG_TXE) == RESET);
    SPI_I2S_SendData(KTH7823_SPI, data);

    while (SPI_I2S_GetFlagStatus(KTH7823_SPI, SPI_I2S_FLAG_RXNE) == RESET);
    return SPI_I2S_ReceiveData(KTH7823_SPI);
}

/**
 * @brief  ��ȡKTH7823ԭʼ16λ�Ƕ�ֵ
 * @retval 0~65535
 */
uint16_t KTH7823_ReadRawAngle(void)
{
    uint16_t raw;

    KTH7823_CS_LOW();
    raw = KTH7823_SPI_ReadWrite16(0x0000); // ���Ƕ�ֻ�跢����16λ����
    KTH7823_CS_HIGH();

    return raw;
}

/**
 * @brief  ��ȡ����ֵ 0 ~ 2��
 */
float KTH7823_ReadAngleRad(void)
{
    uint16_t raw = KTH7823_ReadRawAngle();
    return ((float)raw / KTH7823_ANGLE_MAX) * KTH7823_2PI;
}
