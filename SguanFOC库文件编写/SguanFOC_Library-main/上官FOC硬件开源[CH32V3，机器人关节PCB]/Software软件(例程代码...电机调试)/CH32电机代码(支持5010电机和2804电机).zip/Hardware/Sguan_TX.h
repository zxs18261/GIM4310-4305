#ifndef __SGUAN_TX_H
#define __SGUAN_TX_H

#include "debug.h"

void TX_Init(void);

#endif // SGUAN_TX_H
