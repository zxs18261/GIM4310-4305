#include "KUN_CAN.h"

void KUN_CAN2_Init(void)
{   
	
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE); 
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	
	// AFIO->PCFR1 = (AFIO->PCFR1 & ~(0x3 << 13)) | (0x2 << 13);
	GPIO_PinRemapConfig(GPIO_Remap_CAN2, ENABLE);


    // CAN2_TX PB6 ���츴�����
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    // CAN2_RX PB5 ��������
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    CAN_InitTypeDef CAN_InitStructure;
	CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;    //����ģʽ
	CAN_InitStructure.CAN_Prescaler = 36;            //��Ƶϵ���������� 
	CAN_InitStructure.CAN_BS1 = CAN_BS1_13tq;         //ָ��BS1��Tq��
	CAN_InitStructure.CAN_BS2 = CAN_BS2_2tq;	     //ָ��BS2��Tq��
	CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;         //��ͬ����������    
    CAN_InitStructure.CAN_TTCM = DISABLE;            //ʱ�䴥��ͨ��ģʽ
    CAN_InitStructure.CAN_ABOM = DISABLE;             //�����Զ��ָ�
    CAN_InitStructure.CAN_AWUM = DISABLE;            //�Զ�����
    CAN_InitStructure.CAN_NART = DISABLE;            //���Զ��ش�
    CAN_InitStructure.CAN_RFLM = DISABLE;            //FIFO����
    CAN_InitStructure.CAN_TXFP = DISABLE;            //IDС���ȷ���
    CAN_Init(CAN2, &CAN_InitStructure);

	
	CAN_FilterInitTypeDef CAN_InitStrucyure;
	CAN_InitStrucyure.CAN_FilterNumber = 14;  	
	CAN_InitStrucyure.CAN_FilterIdHigh = 0x0000;
	CAN_InitStrucyure.CAN_FilterIdLow = 0x0000;
	CAN_InitStrucyure.CAN_FilterMaskIdHigh = 0x0000;
	CAN_InitStrucyure.CAN_FilterMaskIdLow = 0x0000;
	CAN_InitStrucyure.CAN_FilterScale = CAN_FilterScale_32bit;
	CAN_InitStrucyure.CAN_FilterMode = CAN_FilterMode_IdMask;        
	CAN_InitStrucyure.CAN_FilterActivation = ENABLE;
	CAN_InitStrucyure.CAN_FilterFIFOAssignment = CAN_Filter_FIFO0;      //���������
	CAN_FilterInit(&CAN_InitStrucyure);
}

void KUN_CAN2_Transmit(uint32_t ID, uint8_t Length, uint8_t *Data)
{	
	CanTxMsg TxMessage;
	TxMessage.StdId = ID;                       //��׼ID
	TxMessage.ExtId = 0;                       //��չID
	TxMessage.IDE = CAN_Id_Standard;            //��չ��־λ
	TxMessage.RTR = CAN_RTR_Data;               //ң�ر�־λ
	TxMessage.DLC = Length;                     //���ݶγ��� 
	for(uint8_t i = 0; i < Length; i++)
	{
			TxMessage.Data [i]= Data[i];        //���ݶ�����
	}
	uint8_t TransmitMailbox = CAN_Transmit(CAN2, &TxMessage);
	uint32_t TimeOut = 0; 
	while(CAN_TransmitStatus(CAN2,TransmitMailbox) != CAN_TxStatus_Ok)
	{
		TimeOut ++;
		if(TimeOut > 100000)
		{
			break;
		}
	}

}

//���ձ�־λ����
uint8_t KUN_CAN2_ReceiveFlag(void)
{
	if(CAN_MessagePending(CAN2, CAN_FIFO0) > 0)
	{
		return 1;
	} 
	return 0;
}

void KUN_CAN2_Receive(uint32_t *ID, uint8_t *Length, uint8_t *Data)
{	
	CanRxMsg RxMessage;
	CAN_Receive(CAN2, CAN_FIFO0, &RxMessage);
	if(RxMessage.IDE == CAN_Id_Standard)
	{
		*ID = RxMessage.StdId;
	}
	else
	{
		*ID = RxMessage.ExtId;
	}                  
	
	if(RxMessage.RTR ==  CAN_RTR_Data)
	{
		*Length = RxMessage.DLC;
		for(uint8_t i = 0; i < *Length; i++)
		{
			Data[i] = RxMessage.Data [i];      
		} 
	}
	else
	{

	}         

}