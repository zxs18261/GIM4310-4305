#ifndef __KUN_CAN_H
#define __KUN_CAN_H

#include "ch32v30x.h"

// ��������
void KUN_CAN2_Init(void);
void KUN_CAN2_Transmit(uint32_t ID, uint8_t Length, uint8_t *Data);
uint8_t KUN_CAN2_ReceiveFlag(void);
void KUN_CAN2_Receive(uint32_t *ID, uint8_t *Length, uint8_t *Data);

#endif